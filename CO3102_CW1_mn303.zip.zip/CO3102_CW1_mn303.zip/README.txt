README

Instructions:

Ensure Python 3. Use the python and the xml file inside. Then run the python and it should print the JSON output in the correct format.

Description:

This script reads the WebServiceProvider.xml and converts selected elements into a JSON format. The output includes method name details, visibility, arguments, exceptions and return type. A pre built XML to JSON function was not used. 